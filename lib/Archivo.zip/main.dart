import 'package:flutter/material.dart';
import 'package:lux_app/screens/onboarding';
import 'package:lux_app/theme/lux_scheme.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  runApp(const LuxApp());
}

class LuxApp extends StatelessWidget {
  const LuxApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'LUX - Compañera Digital',
      debugShowCheckedModeBanner: false,
      theme: luxTheme(Brightness.light),
      darkTheme: luxTheme(Brightness.dark),
      themeMode: ThemeMode.system,
      home: const OnboardingScreen(),
    );
  }
}
